
def StartStopButtonFunction(event_struct):
    return


def TapperStartStopButtonFunction(event_struct):
    return

